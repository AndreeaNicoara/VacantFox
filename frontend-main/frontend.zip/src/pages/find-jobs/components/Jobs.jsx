import R from 'react';
import {
   Outlet,
   useNavigate,
   useParams,
   useSearchParams,
} from 'react-router-dom';
import useSWR from 'swr';
import JobCard from 'components/JobCard';
import { Stack, styled, Typography } from '@mui/material';
import Loading from 'components/Loading';
import { axios } from 'api/fetcher';

export default function Jobs({ filters }) {
   const navigate = useNavigate();
   const params = useParams();
   const [searchParams] = useSearchParams();
   const { data: latestJobs } = useSWR('/jobs');
   // TODO: search could be done using swr
   const [jobs, setJobs] = R.useState(() => latestJobs);
   const [loading, setLoading] = R.useState(false);

   // Always Keep the first job open
   // but not when there is search filters
   const openFirstJob = R.useCallback(() => {
      if (!jobs?.length) return null;

      navigate(`/find-jobs/${jobs[0].slug}`, { replace: true });
   }, [navigate, jobs]);

   R.useEffect(() => {
      // checking if there is any search params
      // e.g. ?category=Sales
      if (searchParams.values().next().value) return;

      // already a job open
      if (params?.slug) return;

      openFirstJob();
   }, [openFirstJob, searchParams]);

   R.useEffect(() => {
      if (!filters) return;
      if (!Object.keys(filters).length) return;

      setLoading(true);

      // TODO: yes
      axios
         .post('/search', filters)
         .then(res => {
            setLoading(false);
            setJobs(res.data);
         })
         .catch(e => {
            setLoading(false);
            throw new Error(e);
         });
   }, [filters]);

   if (loading)
      return (
         <Root>
            <Loading />
         </Root>
      );

   if (!jobs?.length)
      return (
         <Root>
            <Typography variant='h2' textAlign='center'>
               No jobs found
            </Typography>
         </Root>
      );

   return (
      <Root>
         <Stack gap={2}>
            {jobs?.map(job => (
               <JobCard key={job.slug} {...job} />
            ))}
         </Stack>

         {/* Required, even if Outlet elements(route) have their own Suspense boundary */}
         <R.Suspense fallback={<Loading />}>
            <Outlet />
         </R.Suspense>
      </Root>
   );
}

const Root = styled('div')(({ theme }) => ({
   paddingTop: theme.spacing(6),
   paddingBottom: theme.spacing(6),
   display: 'flex',
   gap: theme.spacing(3),
}));
